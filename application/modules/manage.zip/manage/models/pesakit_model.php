<?php


class Pesakit_model extends CI_Model
{
    public function get_all_pesakit()
    {
      $query =  $this->db->get("EV_T01_PESAKIT");
      return $query;
    }


    function delete_pesakit($id_pesakit){
        $this->db
    ->where("T01_ID_PESAKIT", $id_pesakit)
    ->delete("EV_T01_PESAKIT");
    }
}


