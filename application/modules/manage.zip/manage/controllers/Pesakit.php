<?php


class Pesakit extends Admin_Controller
{


    public function __construct() //adalah utk mewakili skali sahaja dlm overall bagi coding($this->load->model("vehicle_model");)
    {
        parent::__construct();
    $this->load->model("pesakit_model");
    }


    public function listpesakit()
    {
        $this->load->model("pesakit_model");//utk panggil model vehicle dlm vehicle_model


        //$data = $this->db->get("EV_T01_PESAKIT");


        $data = $this->pesakit_model->get_all_pesakit();


        $this->template->title("Senarai pesakit");
        $this->template->set("data", $data);//hantar variable data ke view
        $this->template->render();


    }


    public function delete($id_pesakit, $id2="")
     {
    //$id... merujuk kepada parameter which is 1 parameter
    // in url(manage/kenderaan/listkend/1)


    $this->load->model("pesakit_model");
    $this->pesakit_model->delete_pesakit($id_pesakit);
   
    redirect (module_url("pesakit/listpesakit"));
 }


 public function add()
 {
   $no_xray = $this->input->post("no_xray");//nama dlm () mesti sama dgn dlm name in form_add() views
   $nama_pesakit= $this->input->post("nama_pesakit");
   $no_rujukan = $this->input->post("no_rujukan");
   $jantina = $this->input->post("jantina");
   $kategori = $this->input->post("kategori");
   $bhg_utama = $this->input->post("bhg_utama");
   $sub_bhg = $this->input->post("sub_bhg");


   $data_to_insert = [
    "T01_NO_XRAY" => $no_xray,
    "T01_NAMA_PESAKIT" => $nama_pesakit,
    "T01_NO_RUJUKAN" => $no_rujukan,
    "T01_JANTINA" => $jantina,
    "T01_KATEGORI" => $kategori,
    "T01_BAHAGIAN_UTAMA" => $bhg_utama,
    "T01_SUB_BAHAGIAN" => $sub_bhg,
];
 
$this->db->insert("EV_T01_PESAKIT", $data_to_insert);


redirect (module_url("pesakit/listpesakit"));


 }


 public function form_add()
 {
    $this->template->render();
    //echo "123";
 }


 public function form_edit($id_pesakit)//form edit mesti kena ada terima parameter
 {
    $pesakit = $this->db
    ->where("T01_ID_PESAKIT", $id_pesakit)
    ->get("EV_T01_PESAKIT")
    ->row();


   
    $this->template->set("pesakit", $pesakit);
    $this->template->render();
    //echo "123";
   
 }


 public function save($id_pesakit)
 {
    $no_xray = $this->input->post("no_xray");//nama dlm () mesti sama dgn dlm name in form_add() views
    $nama_pesakit= $this->input->post("nama_pesakit");
    $no_rujukan = $this->input->post("no_rujukan");
    $jantina = $this->input->post("jantina");
    $kategori = $this->input->post("kategori");
    $bhg_utama = $this->input->post("bhg_utama");
    $sub_bhg = $this->input->post("sub_bhg");
 
    $data_to_update = [
     "T01_NO_XRAY" => $no_xray,
     "T01_NAMA_PESAKIT" => $nama_pesakit,
     "T01_NO_RUJUKAN" => $no_rujukan,
     "T01_JANTINA" => $jantina,
     "T01_KATEGORI" => $kategori,
     "T01_BAHAGIAN_UTAMA" => $bhg_utama,
     "T01_SUB_BAHAGIAN" => $sub_bhg,
];
 
$this->db
->where("T01_ID_PESAKIT", $id_pesakit )
->update("EV_T01_PESAKIT", $data_to_update);


redirect (module_url("pesakit/listpesakit"));


 }
}
