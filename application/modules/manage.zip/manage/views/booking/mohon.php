<div class="col-lg-12">
  <div class="card">
	<div class="px-4 py-3 border-bottom">
	  <h5 class="card-title fw-semibold mb-0">BORANG PEMOHONAN KELUAR KAMPUS MENJALANKAN PENYELIDIKAN</h5>
	
	</div>
	<div class="card-body">
	  <div class="mb-4 row align-items-center"> 
		<label for="exampleInputText5" class="form-label fw-semibold col-sm-3 col-form-label text-end">Name</label>
		<div class="col-sm-9">
		  NOORHAZREEN BINTI AMRI
		</div>
	  </div>
	  <div class="mb-4 row align-items-center"> 
		<label for="exampleInputText5" class="form-label fw-semibold col-sm-3 col-form-label text-end">No Matrik</label>
		<div class="col-sm-9">
		  S62000
		</div>
	  </div>
	  <div class="mb-4 row align-items-center"> 
		<label for="exampleInputText5" class="form-label fw-semibold col-sm-3 col-form-label text-end">Penyelia</label>
		<div class="col-sm-9">
		  PROFESOR MADYA DR MUSTAFA BIN MAN
		</div>
	  </div>
	  <div class="mb-4 row align-items-center"> 
		<label for="exampleInputText5" class="form-label fw-semibold col-sm-3 col-form-label text-end">Mula</label>
		<div class="col-sm-9">
		  <input type="text" class="form-control" id="exampleInputText6" placeholder="dd/mm/yyyy">
		</div>
	  </div>
	  <div class="mb-4 row align-items-center"> 
		<label for="exampleInputText5" class="form-label fw-semibold col-sm-3 col-form-label text-end">Hingga</label>
		<div class="col-sm-9">
		  <input type="text" class="form-control" id="exampleInputText6" placeholder="dd/mm/yyyy">
		</div>
	  </div>
	  <div class="mb-4 row align-items-center">
		<label for="exampleInputText6" class="form-label fw-semibold col-sm-3 col-form-label text-end">Phone
		  no</label>
		<div class="col-sm-9">
		  <div class="input-group">
			<input type="text" class="form-control" id="exampleInputText6" placeholder="123 4567 201">
		  </div>
		</div>
	  </div>
	  <div class="mb-4 row align-items-center">
		<label for="startDate" class="form-label fw-semibold col-sm-3 col-form-label text-end">Tujuan</label>
		<div class="col-sm-9">
		  <div class="input-group">
			<input type="text" class="form-control" id="exampleInputText6" placeholder="Tujuan">
		  </div>
		</div>
	  </div>
	  <div class="mb-4 row align-items-center">
		<label for="startDate" class="form-label fw-semibold col-sm-3 col-form-label text-end">Jenis Pengangkutan</label>
		<div class="col-sm-9">
		  <div class="input-group">
			<select class="form-select" id="exampleInputselect" aria-label="Default select example">
                        <option selected="">Kenderaan Sendiri</option>
                        <option value="1">Kenderaan Universiti</option>
						<option value="2">Pengangkutan Awam</option>
                      </select>
		  </div>
		</div>
	  </div>
	  <div class="mb-4 row align-items-center">
		<label for="startDate" class="form-label fw-semibold col-sm-3 col-form-label text-end">Alasan Sekiranya Menggunakan Kenderaan Sendiri</label>
		<div class="col-sm-9">
		  <div class="input-group">
			<textarea type="text" class="form-control" id="exampleInputText6" placeholder="Alasan" rows"4"> </textarea>
		  </div>
		</div>
	  </div>
	   <div class="row">
                          <div class="col-sm-3"></div>
                          <div class="col-sm-9">
                            <div class="d-flex align-items-center gap-6">
                              <a class="btn btn-primary" href="<?=site_url("admin/ccc/detail")?>">Submit</a>
                              <button class="btn bg-danger-subtle text-danger">Cancel</button>
                            </div>
                          </div>
                        </div>
	 
	  </div>
	</div>
  </div>
  
  