<form method ="POST" action ="<?php echo module_url("pesakit/save/".$pesakit->T01_ID_PESAKIT)?>">
<div class="col-lg-12">
  <div class="card">
  <div class="px-4 py-3 border-bottom">
    <h5 class="card-title fw-semibold mb-0">EDIT PESAKIT</h5>
 
  </div>
  <!-- No Xray -->
  <div class="mb-4 row align-items-center">
        <label for="no_xray" class="form-label fw-semibold col-sm-3 col-form-label text-end">No Xray</label>
        <div class="col-sm-9">
          <input type="text" class="form-control" id="no_xray" name="no_xray" value="<?php echo $pesakit->T01_NO_XRAY?>">
        </div>
      </div>


      <!-- Nama Pesakit -->
      <div class="mb-4 row align-items-center">
        <label for="nama_pesakit" class="form-label fw-semibold col-sm-3 col-form-label text-end">Nama Pesakit</label>
        <div class="col-sm-9">
          <input type="text" class="form-control" id="nama_pesakit" name="nama_pesakit" value="<?php echo $pesakit->T01_NAMA_PESAKIT?>">
        </div>
      </div>


      <!-- No Rujukan -->
      <div class="mb-4 row align-items-center">
        <label for="no_rujukan" class="form-label fw-semibold col-sm-3 col-form-label text-end">No Rujukan</label>
        <div class="col-sm-9">
          <input type="text" class="form-control" id="no_rujukan" name="no_rujukan" value="<?php echo $pesakit->T01_NO_RUJUKAN?>">
        </div>
      </div>


      <!-- Jantina -->
      <div class="mb-4 row align-items-center">
        <label for="jantina" class="form-label fw-semibold col-sm-3 col-form-label text-end">Jantina</label>
        <div class="col-sm-9">
          <select class="form-select" id="jantina" name="jantina" value="<?php echo $pesakit->T01_JANTINA?>">
            <option value="" selected disabled>Sila Pilih</option>
            <option value="Lelaki">Lelaki</option>
            <option value="Perempuan">Perempuan</option>
          </select>
        </div>
      </div>


      <!-- Kategori -->
      <div class="mb-4 row align-items-center">
        <label for="kategori" class="form-label fw-semibold col-sm-3 col-form-label text-end">Kategori</label>
        <div class="col-sm-9">
          <select class="form-select" id="kategori" name="kategori" value="<?php echo $pesakit->T01_KATEGORI?>">
            <option value="" selected disabled>Sila Pilih</option>
            <option value="Pelajar">Pelajar</option>
            <option value="Staff">Staff</option>
            <option value="Komuniti">Komuniti</option>
            <option value="Tanggungan">Tanggungan</option>
            <option value="Pesara">Pesara</option>
          </select>
        </div>
      </div>


      <!-- Pilihan Utama -->
      <div class="mb-4 row align-items-center">
        <label for="bhg_utama" class="form-label fw-semibold col-sm-3 col-form-label text-end">Pilihan Utama</label>
        <div class="col-sm-9">
          <select class="form-select" id="bhg_utama" name="bhg_utama" value="<?php echo $pesakit->T01_BAHAGIAN_UTAMA?>">
            <option value="" selected disabled>Sila Pilih</option>
            <option value="Skull and Head">Skull and Head</option>
            <option value="Spine">Spine</option>
            <option value="Chest">Chest</option>
            <option value="Abdomen">Abdomen</option>
            <option value="Upper Extremities">Upper Extremities</option>
            <option value="Lower Extremities">Lower Extremities</option>
          </select>
        </div>
      </div>


      <!-- Pilihan Sub -->
      <div class="mb-4 row align-items-center">
        <label for="sub_bhg" class="form-label fw-semibold col-sm-3 col-form-label text-end">Pilihan Sub</label>
        <div class="col-sm-9">
          <select class="form-select" id="sub_bhg" name="sub_bhg" value="<?php echo $pesakit->T01_SUB_BAHAGIAN?>">
            <option value="" selected disabled>Pilih Pilihan Utama Dulu</option>
          </select>
        </div>
      </div>


      <!-- Buttons -->
      <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-9">
          <div class="d-flex align-items-center gap-6">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <button type="button" class="btn bg-danger-subtle text-danger" onclick="history.back();">Cancel</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>


<script>
  const subOptions = {
    "Skull and Head": ["Skull (AP/PA and lateral views)", "Sinuses (paranasal sinuses)", "Facial Bones", "Mandible (jaw)", "Temporomandibular Joint (TMJ)"],
    "Spine": ["Cervical Spine (neck)", "Thoracic Spine (mid-back)", "Lumbar Spine (lower back)", "Sacrum and Coccyx", "Full Spine (scoliosis studies)"],
    "Chest": ["Lungs", "Heart", "Ribs", "Sternum", "Clavicle (collarbone)", "Diaphragm"],
    "Abdomen": ["Kidneys, Ureters, and Bladder (KUB)", "Gas patterns (for bowel obstruction or perforation)", "Foreign Body Localization"],
    "Upper Extremities": ["Shoulder", "Humerus (upper arm)", "Elbow", "Forearm (radius and ulna)", "Wrist", "Hand", "Fingers"],
    "Lower Extremities": ["Pelvis", "Hip", "Femur (thigh bone)", "Knee", "Tibia and Fibula (lower leg)", "Ankle", "Foot", "Toes"]
  };


  document.getElementById('bhg_utama').addEventListener('change', function () {
    const selectedOption = this.value;
    const subOptionSelect = document.getElementById('sub_bhg');
    subOptionSelect.innerHTML = ''; // Clear previous options
    if (selectedOption) {
      subOptionSelect.disabled = false;
      subOptionSelect.innerHTML = '<option value="" selected disabled>Sila Pilih</option>';
      subOptions[selectedOption].forEach(subOption => {
        const option = document.createElement('option');
        option.value = subOption;
        option.textContent = subOption;
        subOptionSelect.appendChild(option);
      });
    } else {
      subOptionSelect.disabled = true;
      subOptionSelect.innerHTML = '<option value="" selected disabled>Pilih Pilihan Utama Dulu</option>';
    }
  });
</script>

